package it.unisa.dia.gas.plaf.jpbc.field.poly;

import junit.framework.TestCase;

/**
 * @author Angelo De Caro (angelo.decaro@gmail.com)
 */
public class HilbertPolyGeneratorTest extends TestCase {

    public void testHilbertPolyRoot() {
/*
        HilbertPolyGenerator hilbertPolyGenerator = new HilbertPolyGenerator(59);
        BigInteger[] hilbertPolyCoeffs = hilbertPolyGenerator.getHilbertPoly();

        PolyField field = new PolyField(new ZrField(BigInteger.valueOf(17)));
        PolyElement hilbertPoly = field.newElement();
        hilbertPoly.setFromCoefficientMonic(hilbertPolyCoeffs);

        System.out.println("hilbertPoly = " + hilbertPoly);

        Element root = hilbertPoly.findRoot();

        System.out.println("root = " + root);
*/
    }

}
