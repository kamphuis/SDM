package it.unisa.dia.gas.jpbc.benchmark;

/**
 * @author Angelo De Caro (angelo.decaro@gmail.com)
 */
public interface Benchmark {

    String toHTML();

}
