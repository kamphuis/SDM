/*
 * Decrypt the specified ciphertext using the given private key.
 */
public void dec(String pubfile, String prvfile, String encfile, String decfile) 
