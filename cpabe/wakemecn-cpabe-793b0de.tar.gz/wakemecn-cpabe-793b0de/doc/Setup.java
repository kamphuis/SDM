/*
 * Generate a public key and corresponding master secret key.
 */
public void setup(String pubfile, String mskfile)
