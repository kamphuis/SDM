/*
 * Generate a private key with the given set of attributes.
 */
public void keygen(String pubfile, String prvfile, String mskfile, String attr_str)
