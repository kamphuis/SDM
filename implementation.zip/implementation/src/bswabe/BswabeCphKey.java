package bswabe;

import it.unisa.dia.gas.jpbc.Element;

public class BswabeCphKey {
	/*
	 * This class is defined for some classes who return both cph and key.
	 */
	public BswabeCph cph;
	public Element key;
}
