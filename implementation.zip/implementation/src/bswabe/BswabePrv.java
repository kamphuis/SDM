package bswabe;

import java.util.ArrayList;

import it.unisa.dia.gas.jpbc.Element;

public class BswabePrv {
	/*
	 * A private key
	 */
	Element d; /* G_2 */
	ArrayList<BswabePrvComp> comps; /* BswabePrvComp */
}